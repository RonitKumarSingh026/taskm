﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TaskMinderAPI.Models.Domain;
using TaskMinderAPI.Models.Data;
using TaskMinderAPI.Models.DTO;
using Microsoft.EntityFrameworkCore;

namespace TaskMinderAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TaskItemsController : ControllerBase
    {
        private readonly TaskMinderDbContext dbContext;
        public TaskItemsController(TaskMinderDbContext dbContext)
        {
                this.dbContext = dbContext;
        }


        //GET all tasks in a list form
        [HttpGet]
         public async Task<IActionResult> GetAllTasks()
        {
            //Get Data from the database domain models
            var taskDomainModel = await dbContext.TaskItems.ToListAsync();
            return Ok(taskDomainModel);

        }


        //GET Task By Id
        [HttpGet]
        [Route("{id}")]
        public async Task<IActionResult> GetTaskById([FromRoute] int id)
        {
            try
            {
                var task = await dbContext.TaskItems.FirstOrDefaultAsync(x => x.Id == id);

                if (task == null)
                {
                    return NotFound();
                }
                return Ok(task);

            }
            catch (Exception e)
            {
                return StatusCode(500, "An error occurred while fetching the desired task.");
            }

        }

        //POST or Add New Tasks
        [HttpPost]
        public async Task<IActionResult> CreateTask([FromBody] AddTaskDto addTaskDto)
        {
            //Mapping Dto To Domain Model
            try
            {
                var taskDomainModel = new TaskItem
                {
                    Title = addTaskDto.Title,
                    Description = addTaskDto.Description,
                    DueDate = addTaskDto.DueDate,
                    Status = addTaskDto.Status,
                };

                await dbContext.TaskItems.AddAsync(taskDomainModel);
                dbContext.SaveChanges();

                if (taskDomainModel.Status == "Completed")
                {
                    taskDomainModel.IsActive = false;
                    dbContext.TaskItems.Update(taskDomainModel);
                    dbContext.SaveChanges();
                }


                //Mapping Domain Model to Dto to pass to the UI
                var taskDto = new AddTaskDto
                {
                    Title = taskDomainModel.Title,
                    Description = taskDomainModel.Description,
                    DueDate = taskDomainModel.DueDate,
                    Status = taskDomainModel.Status,
                };

                return Ok(taskDto);
            }
            catch (Exception e)
            {
                return StatusCode(500, "An error occurred while adding the task.");
            }

        }

        //UPDATE Existing Task
        [HttpPut]
        [Route("{id}")]

        public async Task<IActionResult> UpdateTask([FromRoute] int id,[FromBody] AddTaskDto addTaskDto)
        {
            try
            {

                var taskDomainModel = await dbContext.TaskItems.FirstOrDefaultAsync(x => x.Id == id);

                if (taskDomainModel == null)
                {
                    return NotFound();
                }
                
                taskDomainModel.Title = addTaskDto.Title;
                taskDomainModel.Description = addTaskDto.Description;
                taskDomainModel.DueDate = addTaskDto.DueDate;
                taskDomainModel.Status = addTaskDto.Status;

                if (taskDomainModel.Status == "Completed")
                {
                    taskDomainModel.IsActive = false;
                   
                }

                await dbContext.SaveChangesAsync();
                
                //Mapping Domain Model to Dto to pass to the UI
                var taskDto = new AddTaskDto
                {
                    Title = taskDomainModel.Title,
                    Description = taskDomainModel.Description,
                    DueDate = taskDomainModel.DueDate,
                    Status = taskDomainModel.Status,
                };

                return Ok(taskDto);
            }
            catch (Exception e)
            {
                return StatusCode(500, "An error occurred while updating the task.");
            }

        }

        //DELETE  Task
        [HttpDelete]
        [Route("{id}")]
        public async Task<IActionResult> DeleteTask([FromRoute] int id)
        {
            try
            {
                var taskDomainModel = await dbContext.TaskItems.FirstOrDefaultAsync(x => x.Id == id);

                if (taskDomainModel == null)
                {
                    return NotFound();
                }
               taskDomainModel.IsActive = false;
               
                await dbContext.SaveChangesAsync();

                //Mapping Domain Model to Dto to pass to the UI
                var taskDto = new AddTaskDto
                {
                    Title = taskDomainModel.Title,
                    Description = taskDomainModel.Description,
                    DueDate = taskDomainModel.DueDate,
                    Status = taskDomainModel.Status,
                };

                return Ok(taskDto);
            }
            catch (Exception e)
            {
                return StatusCode(500, "An error occurred while deleting task.");
            }

        }










    }
}
