﻿namespace TaskMinderAPI.Models.DTO
{
    public class AddTaskDto
    {
        public string Title { get; set; } = null!;

        public string? Description { get; set; }

        public DateTime? DueDate { get; set; }

        public string Status { get; set; } = null!;
    }
}
