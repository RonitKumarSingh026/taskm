﻿document.addEventListener('DOMContentLoaded', () => {
    const taskForm = document.getElementById('taskForm');
    const taskList = document.getElementById('taskList');

    const apiBaseUrl = 'http://localhost:5291/api/taskitems'; // Update with your API base URL

    taskForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        const task = {
            title: document.getElementById('title').value,
            description: document.getElementById('description').value,
            dueDate: document.getElementById('dueDate').value,
            status: document.getElementById('status').value
        };

        const response = await fetch(apiBaseUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(task)
        });

        if (response.ok) {
            loadTasks();
        } else {
            console.error('Failed to add task');
        }
    });

    taskList.addEventListener('click', async (e) => {
        if (e.target.tagName === 'BUTTON') {
            const taskId = e.target.dataset.id;
            const action = e.target.dataset.action;

            if (action === 'delete') {
                const response = await fetch(`${apiBaseUrl}/${taskId}`, {
                    method: 'DELETE'
                });

                if (response.ok) {
                    loadTasks();
                } else {
                    console.error('Failed to delete task');
                }
            } else if (action === 'edit') {
                const task = {
                    title: prompt('New title:'),
                    description: prompt('New description:'),
                    dueDate: prompt('New due date:'),
                    status: prompt('New status:')
                };

                const response = await fetch(`${apiBaseUrl}/${taskId}`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(task)
                });

                if (response.ok) {
                    loadTasks();
                } else {
                    console.error('Failed to update task');
                }
            }
        }
    });

    async function loadTasks() {
        const response = await fetch(apiBaseUrl);
        const tasks = await response.json();

        taskList.innerHTML = '';
        tasks.forEach(task => {
            const li = document.createElement('li');
            li.textContent = `${task.title} - ${task.description} - ${task.dueDate} - ${task.status} - ${task.isActive}`;
            li.innerHTML += `
                <button data-id="${task.id}" data-action="edit">Edit</button>
                <button data-id="${task.id}" data-action="delete">Delete</button>
            `;
            taskList.appendChild(li);
        });
    }

    loadTasks();
});